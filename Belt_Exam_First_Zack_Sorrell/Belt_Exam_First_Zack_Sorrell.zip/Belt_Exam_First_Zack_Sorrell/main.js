function hide(){
    var acceptButton = document.querySelector("#plant-alert");
    acceptButton.remove();
}

function shoppingCart(){
    alert("Your cart is empty")
}

function newPic(){
    document.getElementById("event").src = "images/succulents-2.jpg"
}

function oldPic(){
    document.getElementById("event").src = "images/succulents-1.jpg"
}