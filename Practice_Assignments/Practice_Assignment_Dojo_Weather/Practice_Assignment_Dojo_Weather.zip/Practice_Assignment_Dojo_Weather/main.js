function message(){
    alert("Loading weather report...")
}

function hide(){
    var cookiealert = document.querySelector("#cookie-alert")
    cookiealert.remove()
}



