function Logout(element){
    element.innerText = "Logout";
}

function hide(element){
    element.remove()
}
function onclick(element){
    alert("Ninja was liked!")
}