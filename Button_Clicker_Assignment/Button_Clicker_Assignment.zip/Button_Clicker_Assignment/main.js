function Logout(element){
    element.innerText = "Logout";
}

function hide(element){
    element.remove()
}
function alert(element){
    element.alert()
}